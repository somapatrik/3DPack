Public Class Register


    Private Sub bRegister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bRegister.Click

    End Sub
End Class