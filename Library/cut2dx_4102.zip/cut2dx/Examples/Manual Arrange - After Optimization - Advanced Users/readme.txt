
This example is for advanced users only. Go in the other directory "Optimization" if you are looking for some optimization examples.

This example shows how to move a piece by mouse.


Do the followings:

1. Start the program.
2. Press Start button. A layout is generated.
3. Move a piece by drag and drop. Drop it on a waste rectangle larger than the piece.