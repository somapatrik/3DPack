for using cut2dx with java you have to call native code from java code.

this can be acomplished with JNI.

here we use a simple solution: using the Jacob package.

http://sourceforge.net/projects/jacob-project/