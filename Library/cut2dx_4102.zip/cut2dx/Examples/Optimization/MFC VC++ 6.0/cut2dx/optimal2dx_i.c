/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun May 03 12:17:21 2009
 */
/* Compiler settings for C:\tmp\cut2dx\optimal2dx.IDL:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID LIBID_optimal2dx = {0xE1AEC0A5,0x8A7C,0x47BC,{0xB2,0xBE,0x99,0x2C,0xEB,0x0C,0x9B,0x0D}};


const IID IID_IOptimization2DX = {0xE7C266EF,0x2634,0x42F9,{0xA1,0xAC,0x96,0xC7,0xDB,0x05,0x0D,0xB2}};


const IID DIID_IOptimization2DXEvents = {0xE8BE5D3C,0x9B56,0x4892,{0x8F,0x45,0x3C,0xC0,0x08,0x85,0x7C,0x63}};


const CLSID CLSID_Optimization2DX = {0x50C1F407,0xFFDB,0x4A07,{0x8A,0xD8,0x35,0x65,0x79,0xBF,0x3A,0x40}};


#ifdef __cplusplus
}
#endif

