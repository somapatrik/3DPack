for more info on how to create handle automation in MFC you may read this document:

http://www.codeproject.com/KB/COM/vbeventswithvc.aspx